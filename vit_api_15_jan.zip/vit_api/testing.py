import requests
import json

def post():
 
    URL="http://127.0.0.1:8000/"
    inp=input("enter your number : ")
    invalid_entry =""
    valid=""
    maximum=""
    minimum = ""
    average = ""
    data = {'inp_from_user':inp}
    json_data=json.dumps(data)
    r=requests.post(url=URL , data=json_data)
    try:
        print(r.json())
    except Exception:
        print(Exception)

post()
    
