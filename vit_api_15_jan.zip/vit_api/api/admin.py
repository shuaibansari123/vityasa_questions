from django.contrib import admin
from .models import UserInput
# Register your models here.
admin.site.register(UserInput)
