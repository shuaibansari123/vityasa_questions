from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
import io
from rest_framework.parsers import JSONParser
from .serializers import User_Serializer
from django.views.decorators.csrf import csrf_exempt
import json
from rest_framework.renderers import JSONRenderer
from .models import UserInput
from django.core.serializers import serialize
# Create your views here.


@csrf_exempt
def start(request, slug):
    mydict = {'invalid_entry': 0, 'valid_entry': 0,
              'minimun': 0, 'maximum': 0, 'average': 0}
    new_quary = UserInput(inp_from_user=slug)
    new_quary.save()
    all_data = UserInput.objects.all()
    seri =User_Serializer(all_data,many=True)
    mlist = []
    valid_input_list = []
    invalid_input_list = []
    for i in seri.data:
        for j in i.keys():
            mlist.append(i[j])
    valid_list = mlist[1::2]
    
    for x in valid_list:
        if isinstance(x, int):
            if x == 0 or x < 0:
                invalid_input_list.append(x)
            else:
                valid_input_list.append(x)
            
    print(invalid_input_list)
    return JsonResponse({"valid":len(valid_input_list),"invalid":len(invalid_input_list),"max":0,"min":0,"avg":0}, safe=False)
