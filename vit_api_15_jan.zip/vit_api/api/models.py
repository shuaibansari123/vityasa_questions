from django.db import models

# Create your models here.
class UserInput(models.Model):
    inp_from_user = models.IntegerField()
    
  